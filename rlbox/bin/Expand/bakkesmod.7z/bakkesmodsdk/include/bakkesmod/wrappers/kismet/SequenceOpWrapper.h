#pragma once
#include "SequenceObjectWrapper.h"

class BAKKESMOD_PLUGIN_IMPORT SequenceOpWrapper : public SequenceObjectWrapper {
public:
	CONSTRUCTORS(SequenceOpWrapper)


private:
	PIMPL
};