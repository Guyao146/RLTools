https://bakkesmod.fandom.com/wiki/BakkesMod_Wiki
