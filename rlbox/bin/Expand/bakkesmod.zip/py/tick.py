
import bakkesmod

def on_tick():
	cvar_manager.log("tick2")